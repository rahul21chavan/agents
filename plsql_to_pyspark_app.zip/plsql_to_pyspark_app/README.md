# PL/SQL to PySpark Converter

A FastAPI-based application that chunks PL/SQL code and simulates conversion to PySpark.
