from fastapi import APIRouter, Request
from backend.utils.plsql_chunker import chunk_plsql_code
from backend.agents.llm_agent import convert_to_pyspark

router = APIRouter()

@router.post("/convert")
async def convert(request: Request):
    payload = await request.json()
    code = payload.get("code", "")
    code_type = payload.get("code_type", "plsql")

    if code_type.lower() == "plsql":
        chunks = chunk_plsql_code(code)
    else:
        return {"error": "Unsupported code_type. Use 'plsql'."}

    pyspark_outputs = [convert_to_pyspark(chunk) for chunk in chunks]
    return {"converted_code": "\n\n".join(pyspark_outputs)}
