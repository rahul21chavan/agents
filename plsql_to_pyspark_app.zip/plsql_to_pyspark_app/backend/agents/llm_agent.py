def convert_to_pyspark(chunk: str) -> str:
    return f"# PySpark translation of:\n{chunk}"
