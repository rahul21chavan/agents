def chunk_plsql_code(code: str):
    blocks = []
    current_block = []
    lines = code.splitlines()
    start_keywords = ['CREATE', 'DECLARE', 'BEGIN', 'IF', 'FOR', 'WHILE', 'LOOP']
    end_keywords = ['END;', 'END IF;', 'END LOOP;', 'END;']
    inside_block = False

    for line in lines:
        stripped = line.strip()
        if any(stripped.upper().startswith(kw) for kw in start_keywords) and not inside_block:
            if current_block:
                blocks.append("\n".join(current_block))
                current_block = []
            inside_block = True
        current_block.append(line)
        if any(stripped.upper().endswith(kw) for kw in end_keywords) and inside_block:
            blocks.append("\n".join(current_block))
            current_block = []
            inside_block = False

    if current_block:
        blocks.append("\n".join(current_block))
    return blocks
