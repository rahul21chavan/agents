
def merge_agent(pyspark_chunks: list) -> str:
    return "\n\n".join(pyspark_chunks)
