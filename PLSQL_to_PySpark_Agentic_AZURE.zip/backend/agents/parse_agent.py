
import re

def parse_agent(plsql_code: str, max_lines: int = 100) -> list:
    lines = plsql_code.strip().splitlines()
    chunks = []
    current_chunk = []
    line_count = 0

    for line in lines:
        current_chunk.append(line)
        line_count += 1

        if line.strip() == "/" or line_count >= max_lines:
            chunk = "\n".join(current_chunk).strip()
            if chunk:
                chunks.append(chunk)
            current_chunk = []
            line_count = 0

    if current_chunk:
        chunk = "\n".join(current_chunk).strip()
        if chunk:
            chunks.append(chunk)

    return chunks
