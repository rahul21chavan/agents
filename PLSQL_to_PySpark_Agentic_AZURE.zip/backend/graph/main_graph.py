
from backend.agents.parse_agent import parse_agent
from backend.agents.llm_rule_agent import llm_rule_agent
from backend.agents.validate_agent import validate_agent
from backend.agents.merge_agent import merge_agent

def run_pipeline(plsql_code: str) -> dict:
    chunks = parse_agent(plsql_code)
    pyspark_chunks = []

    for chunk in chunks:
        pyspark = llm_rule_agent(chunk)
        if validate_agent(pyspark):
            pyspark_chunks.append(pyspark)
        else:
            pyspark_chunks.append("# Invalid conversion")

    final_output = merge_agent(pyspark_chunks)
    return {
        "chunks": chunks,
        "pyspark_chunks": pyspark_chunks,
        "final_pyspark_code": final_output
    }
