# backend/agents/validate_agent.py
"""
Light‑weight rule‑based validator
► Confirms the generated PySpark resembles real Spark code.
► Guarantees a clear True / False flag so the graph can exit
  (and clears failed_chunks on success to avoid feedback loops).
"""

def validate_node(state: dict) -> dict:
    print("✅ Running Validation Node…")

    logs = state.get("logs", [])
    code = state.get("pyspark_code", "") or ""

    # ── Rule‑1: something was produced ─────────────────────────────
    if len(code.strip()) < 20:
        logs.append("❌ Validation failed – output empty / too short.")
        return {
            **state,
            "validation_passed": False,
            "failed_chunks": ["all"],      # keeps feedback aware
            "logs": logs,
        }

    # ── Rule‑2: look for essential Spark terms ────────────────────
    spark_terms = ["spark.read", ".select(", ".filter(", ".withColumn(", ".groupBy(", ".write"]
    hits = sum(1 for kw in spark_terms if kw in code)

    if hits < 2:          # tweak as you like
        logs.append("❌ Validation failed – not enough Spark operations.")
        return {
            **state,
            "validation_passed": False,
            "failed_chunks": ["logic"],
            "logs": logs,
        }

    # ── Success ───────────────────────────────────────────────────
    logs.append("✅ Validation passed – code looks like PySpark.")
    return {
        **state,
        "validation_passed": True,
        "failed_chunks": [],          # ✨ clear so router can END
        "logs": logs,
    }
