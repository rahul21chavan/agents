# backend/agents/parse_agent.py

import uuid
from agents.utils.plsql_chunker import chunk_plsql_code_v1, save_chunks_to_csv

def parse_node(state: dict) -> dict:
    print("🔍 Parse Node: starting hybrid chunk/parse")

    plsql_code: str = state["plsql_code"]
    ast_blocks = []

    # Use new v2 chunker with macro-aware smart splitting
    raw_chunks = chunk_plsql_code_v1(plsql_code)

    # Convert to AST format with ID and type
    for chunk in raw_chunks:
        ast_blocks.append({
            "id": chunk["id"],
            "type": chunk["type"].upper(),
            "code": chunk["code"]
        })

    # Fallback to UNKNOWN if empty
    if not ast_blocks:
        ast_blocks.append({
            "id": str(uuid.uuid4()),
            "type": "UNKNOWN",
            "code": sas_code
        })

    # Optional: Save for debugging
    save_chunks_to_csv(ast_blocks, "ast_blocks_latest.csv")

    print(f"📦 Parse Node: produced {len(ast_blocks)} AST blocks.")

    return {
        **state,
        "ast_blocks": ast_blocks,
        "logs": state.get("logs", []) + [f"Parse: {len(ast_blocks)} blocks"]
    }
