
import uuid
import re

def chunk_plsql_code_v1(plsql_code: str):
    blocks = []
    lines = plsql_code.splitlines()
    buffer = []
    current_id = lambda: str(uuid.uuid4())

    for line in lines:
        buffer.append(line)
        if re.match(r'\s*END\s*;\s*$', line, re.IGNORECASE) or line.strip().endswith(";"):
            block = "\n".join(buffer).strip()
            if block:
                block_type = "BLOCK" if "BEGIN" in block.upper() else "STATEMENT"
                blocks.append({
                    "id": current_id(),
                    "type": block_type,
                    "code": block
                })
                buffer = []

    # Catch any remaining code
    if buffer:
        block = "\n".join(buffer).strip()
        if block:
            blocks.append({
                "id": current_id(),
                "type": "UNKNOWN",
                "code": block
            })

    return blocks

def save_chunks_to_csv(blocks, filename):
    import pandas as pd
    df = pd.DataFrame(blocks)
    df.to_csv(filename, index=False)
