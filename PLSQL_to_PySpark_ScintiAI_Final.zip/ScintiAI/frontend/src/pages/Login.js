import React, { useState } from "react";
import {
  Box, Button, Card, CardContent,
  CircularProgress, Stack, TextField, Typography
} from "@mui/material";
import { useNavigate, Link as RouterLink } from "react-router-dom";
import { toast } from "react-toastify";
import { motion } from "framer-motion";
import axiosInstance from "../api/axiosInstance";

export default function Login() {
  const [email, setEmail] = useState("");
  const [pwd, setPwd] = useState("");
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const handleLogin = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      const res = await axiosInstance.post("/auth/login", { email, password: pwd });
      localStorage.setItem("access_token", res.data.access_token);
      toast.success("Login successful");
      navigate("/");
    } catch (err) {
      toast.error("Login failed. Please check credentials.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <Box maxWidth={400} mx="auto" mt={8}>
      <Card component={motion.div} initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }}>
        <CardContent>
          <Typography variant="h3" textAlign="center" mb={3}>
            ScintiAI
          </Typography>
          <Typography variant="h5" mb={3} textAlign="center">
            Login
          </Typography>
          <form onSubmit={handleLogin}>
            <Stack spacing={2}>
              <TextField
                label="Email"
                fullWidth
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
              />
              <TextField
                label="Password"
                type="password"
                fullWidth
                value={pwd}
                onChange={(e) => setPwd(e.target.value)}
                required
              />
              <Button
                type="submit"
                variant="contained"
                endIcon={loading && <CircularProgress size={20} />}
                disabled={loading}
              >
                {loading ? "Logging in..." : "Login"}
              </Button>
              <Button component={RouterLink} to="/signup">
                Don't have an account? Signup
              </Button>
            </Stack>
          </form>
        </CardContent>
      </Card>
    </Box>
  );
}
