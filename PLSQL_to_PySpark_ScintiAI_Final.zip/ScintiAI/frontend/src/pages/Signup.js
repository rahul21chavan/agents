import React, { useState } from "react";
import {
  Box,
  Button,
  Card,
  CardContent,
  CircularProgress,
  Stack,
  TextField,
  Typography
} from "@mui/material";
import { useNavigate, Link as RouterLink } from "react-router-dom";
import { toast } from "react-toastify";
import axiosInstance from "../api/axiosInstance";
import { motion } from "framer-motion";

export default function Signup() {
  const [email, setEmail] = useState("");
  const [pwd, setPwd] = useState("");
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const handleSignup = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      await axiosInstance.post("/auth/signup", { email, password: pwd });
      toast.success("Account created successfully");
      navigate("/login");
    } catch (err) {
      toast.error("Signup failed. Try with another email.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <Box maxWidth={400} mx="auto" mt={8}>
      <Card component={motion.div} initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }}>
        <CardContent>
          <Typography variant="h3" textAlign="center" mb={3}>
            ScintiAI
          </Typography>
          <Typography variant="h5" mb={3} textAlign="center">
            Sign Up
          </Typography>
          <form onSubmit={handleSignup}>
            <Stack spacing={2}>
              <TextField
                label="Email"
                fullWidth
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
              />
              <TextField
                label="Password"
                type="password"
                fullWidth
                value={pwd}
                onChange={(e) => setPwd(e.target.value)}
                required
              />
              <Button
                type="submit"
                variant="contained"
                endIcon={loading && <CircularProgress size={20} />}
                disabled={loading}
              >
                {loading ? "Creating..." : "Sign Up"}
              </Button>
              <Button component={RouterLink} to="/login">
                Already have an account? Login
              </Button>
            </Stack>
          </form>
        </CardContent>
      </Card>
    </Box>
  );
}
