
import React, { useState, useEffect } from "react";
import {
  AppBar,
  Toolbar,
  Typography,
  Button,
  Slide,
  useScrollTrigger,
  Menu,
  MenuItem,
  IconButton,
  Avatar,
  Box,
} from "@mui/material";
import { Link as RouterLink, useNavigate, useLocation } from "react-router-dom";
import { motion } from "framer-motion";
import axiosInstance from "../api/axiosInstance";

function HideOnScroll({ children }) {
  const trigger = useScrollTrigger();
  return (
    <Slide appear={false} direction="down" in={!trigger}>
      {children}
    </Slide>
  );
}

export default function Navbar({ toggleTheme }) {
  const navigate = useNavigate();
  const location = useLocation();

  const [tokenValid, setTokenValid] = useState(null); // initially null
  const [email, setEmail] = useState("");
  const [anchorEl, setAnchorEl] = useState(null);
  const [menuOpen, setMenuOpen] = useState(false);

  useEffect(() => {
    const validateToken = async () => {
      const token = localStorage.getItem("access_token");
      if (!token) {
        setTokenValid(false);
        navigate("/login");
        return;
      }
      try {
        const res = await axiosInstance.get("/auth/me");
        setEmail(res.data.email);
        setTokenValid(true);
      } catch {
        localStorage.removeItem("access_token");
        setTokenValid(false);
        navigate("/login");
      }
    };
    validateToken();
  }, [navigate]);

  const handleMenuClick = (e) => {
    setAnchorEl(e.currentTarget);
    setMenuOpen((prev) => !prev);
  };

  const handleMenuClose = () => {
    setMenuOpen(false);
    setAnchorEl(null);
  };

  const handleLogout = () => {
    localStorage.removeItem("access_token");
    setMenuOpen(false);
    setTokenValid(false);
    navigate("/login");
  };

  const navLinks = [
    { path: "/", label: "Home" },
    { path: "/upload", label: "Upload" },
    { path: "/settings", label: "LLM Config" },
  ];

  // 👉 This part moved AFTER hooks
  if (tokenValid === false) return null; // if token invalid, hide navbar
  if (tokenValid === null) return null;  // while verifying, hide navbar temporarily

  return (
    <HideOnScroll>
      <AppBar
        position="sticky"
        elevation={4}
        component={motion.div}
        initial={{ y: -80 }}
        animate={{ y: 0 }}
        sx={{ bgcolor: "primary.main", transition: "all .3s" }}
      >
        <Toolbar sx={{ justifyContent: "space-between" }}>
          <Typography
            variant="h6"
            component={RouterLink}
            to="/"
            color="inherit"
            sx={{ textDecoration: "none", fontWeight: 600 }}
          >
            ScintiAI
          </Typography>

          <Box sx={{ display: "flex", gap: 2, alignItems: "center" }}>
            {navLinks.map((link) => (
              <Box key={link.path} sx={{ position: "relative" }}>
                <Button
                  component={RouterLink}
                  to={link.path}
                  color="inherit"
                  sx={{
                    fontWeight: 500,
                    textTransform: "none",
                    "&:hover": { bgcolor: "primary.dark" },
                  }}
                >
                  {link.label}
                </Button>
                {location.pathname === link.path && (
                  <motion.div
                    layoutId="nav-underline"
                    style={{
                      height: 3,
                      width: "100%",
                      background: "#fff",
                      borderRadius: 2,
                      position: "absolute",
                      bottom: 0,
                      left: 0,
                    }}
                  />
                )}
              </Box>
            ))}

            <IconButton
              onClick={handleMenuClick}
              size="small"
              autoFocus={false}
              sx={{
                ml: 2,
                transition: "all .3s",
                "&:hover": {
                  transform: "scale(1.1)",
                  boxShadow: "0 0 8px rgba(255,255,255,.8)",
                },
              }}
            >
              <Avatar sx={{ width: 34, height: 34 }}>
                {email ? email[0].toUpperCase() : "U"}
              </Avatar>
            </IconButton>

            <Menu
              anchorEl={anchorEl}
              open={menuOpen}
              onClose={handleMenuClose}
              transformOrigin={{ horizontal: "right", vertical: "top" }}
              anchorOrigin={{ horizontal: "right", vertical: "bottom" }}
            >
              <MenuItem disabled>{email}</MenuItem>
              <MenuItem onClick={handleLogout}>Logout</MenuItem>
            </Menu>
          </Box>
        </Toolbar>
      </AppBar>
    </HideOnScroll>
  );
}
