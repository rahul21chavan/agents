import React, { useMemo, useState } from "react";
import ReactDOM from "react-dom/client";
import App from "./App";
import { CssBaseline, ThemeProvider, createTheme } from "@mui/material";
import { ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

const Root = () => {
  const [mode] = useState("light"); // Keep light mode for now, simple

  const theme = useMemo(() => createTheme({
    palette: {
      mode,
      primary: { main: "#4f46e5" },
      secondary: { main: "#06b6d4" }
    },
    typography: {
      fontFamily: [
        'Poppins',
        'Roboto',
        'Helvetica',
        'Arial',
        'sans-serif'
      ].join(','),
    }
  }), [mode]);

  return (
    <ThemeProvider theme={theme}>
      <CssBaseline />
      <App />
      <ToastContainer position="bottom-right" />
    </ThemeProvider>
  );
};

const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(<Root />);
