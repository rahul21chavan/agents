import React, { useEffect, useRef, useState } from "react";
import {
  Box, Button, Card, CardContent, CircularProgress,
  LinearProgress, MenuItem, Select, Stack, TextField, Typography
} from "@mui/material";
import { motion } from "framer-motion";
import { toast } from "react-toastify";
import axiosInstance from "../api/axiosInstance";

export default function UploadSAS() {
  const [file, setFile] = useState(null);
  const [creds, setCreds] = useState([]);
  const [credId, setCredId] = useState("");
  const [uploading, setUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [convertedCode, setConvertedCode] = useState("");
  const [agentStages, setAgentStages] = useState([]);
  const [loadingAgentStages, setLoadingAgentStages] = useState(false);
  const progressRef = useRef(null);

  useEffect(() => {
    axiosInstance.get("/settings/llm").then((res) => setCreds(res.data));
  }, []);

  const handleUpload = async (e) => {
    e.preventDefault();
    if (!file || !credId) return toast.error("Select file & credential");

    const data = new FormData();
    data.append("sas_file", file);
    data.append("cred_id", credId);

    setUploading(true);
    setUploadProgress(0);
    setConvertedCode("");
    setAgentStages([]);
    setLoadingAgentStages(false);

    try {
      const res = await axiosInstance.post("/agent/convert", data, {
        headers: { "Content-Type": "multipart/form-data" },
        onUploadProgress: (progressEvent) => {
          if (progressEvent.total) {
            const percent = Math.round((progressEvent.loaded * 100) / progressEvent.total);
            setUploadProgress(percent);
          }
        }
      });

      setUploadProgress(100);
      setUploading(false);

      // Simulate agent work with animated stages
      setLoadingAgentStages(true);
      scrollToProgress();

      const stages = ["Parsing SAS", "Rule-Based Conversion", "LLM Fallback", "Validation", "Completed"];
      for (let i = 0; i < stages.length; i++) {
        await new Promise(resolve => setTimeout(resolve, 700)); // simulate agent stage
        setAgentStages(prev => [...prev, stages[i]]);
      }

      setConvertedCode(res.data.converted_code);
      setLoadingAgentStages(false);
      toast.success("Conversion Complete!");
    } catch (err) {
      setUploading(false);
      setLoadingAgentStages(false);
      toast.error("Upload/Conversion failed.");
    }
  };

  const scrollToProgress = () => {
    setTimeout(() => {
      progressRef.current?.scrollIntoView({ behavior: "smooth" });
    }, 300);
  };

  return (
    <Box maxWidth={700} mx="auto" mt={5}>
      <Card component={motion.div} initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }}>
        <CardContent>
          <Typography variant="h5" mb={3} textAlign="center">
            Upload SAS Script
          </Typography>
          <form onSubmit={handleUpload}>
            <Stack spacing={2}>
              <Button variant="outlined" component="label">
                {file ? file.name : "Choose .sas File"}
                <input hidden type="file" accept=".sas" onChange={(e) => setFile(e.target.files[0])} />
              </Button>

              <Select value={credId} onChange={(e) => setCredId(e.target.value)} displayEmpty>
                <MenuItem value="">Select LLM Credential</MenuItem>
                {creds.map((c) => (
                  <MenuItem key={c.id} value={c.id}>{c.name} ({c.provider})</MenuItem>
                ))}
              </Select>

              <Button variant="contained" type="submit" disabled={uploading || loadingAgentStages}>
                {(uploading || loadingAgentStages) ? <CircularProgress size={22} /> : "Start Conversion"}
              </Button>
            </Stack>
          </form>

          {(uploading || uploadProgress > 0) && (
            <Box mt={3} ref={progressRef}>
              <Typography>Uploading File... {uploadProgress}%</Typography>
              <LinearProgress variant="determinate" value={uploadProgress} />
            </Box>
          )}

          {loadingAgentStages && (
            <Box mt={4}>
              <Typography variant="h6" mb={2}>Agent Progress</Typography>
              <Stack spacing={2}>
                {agentStages.map((stage, idx) => (
                  <motion.div key={idx} initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
                    <Box display="flex" alignItems="center" gap={2}>
                      <Box width={10} height={10} borderRadius="50%" bgcolor="green" />
                      <Typography>{stage} ✅</Typography>
                    </Box>
                  </motion.div>
                ))}
              </Stack>
            </Box>
          )}

          {convertedCode && (
            <Box mt={4}>
              <Typography variant="h6">Converted PySpark Code</Typography>
              <TextField
                multiline rows={16} fullWidth
                value={convertedCode} InputProps={{ readOnly: true }}
              />
            </Box>
          )}
        </CardContent>
      </Card>
    </Box>
  );
}
