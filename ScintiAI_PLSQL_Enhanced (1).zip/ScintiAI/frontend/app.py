
import streamlit as st
import requests
import os

st.set_page_config(page_title="PL/SQL to PySpark Converter", layout="wide")

st.title("🔄 PL/SQL ➝ PySpark Converter")
st.markdown("Upload your PL/SQL file, and this app will convert it to optimized PySpark code using LLM APIs.")

# Upload Section
st.sidebar.header("📂 Upload PL/SQL File")
uploaded_file = st.sidebar.file_uploader("Choose a .sql or .txt file", type=["sql", "txt"])

# Display file contents in expander
if uploaded_file is not None:
    code = uploaded_file.read().decode("utf-8")
    st.subheader("📄 Uploaded PL/SQL Code")
    with st.expander("Click to view full source code", expanded=False):
        st.code(code, language="sql")

    # Send code to backend for chunking and conversion (mock endpoint below)
    if st.button("🚀 Convert to PySpark"):
        with st.spinner("Chunking and sending to LLM for conversion..."):
            response = requests.post(
                "http://localhost:8000/convert",  # Replace with actual FastAPI endpoint
                json={"plsql_code": code}
            )
            if response.status_code == 200:
                result = response.json()
                chunks = result.get("chunks", [])
                final_output = result.get("final_pyspark_code", "")

                st.subheader("🧩 Code Chunks")
                for i, chunk in enumerate(chunks):
                    with st.expander(f"Chunk {i+1}", expanded=False):
                        st.code(chunk, language="sql")

                st.subheader("🔥 Final PySpark Output")
                st.code(final_output, language="python")

                st.download_button("⬇️ Download PySpark Code", final_output, file_name="converted_pyspark.py")
            else:
                st.error("Conversion failed. Please check backend logs.")
else:
    st.info("Upload a PL/SQL file from the sidebar to begin.")

st.sidebar.markdown("---")
st.sidebar.write("💡 Tip: PL/SQL blocks often end with `/` which is handled for intelligent chunking.")
