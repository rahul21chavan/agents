# backend/agents/feedback_agent.py
MAX_RETRIES = 1

def feedback_node(state):
    print("🔁 Feedback Node Triggered")

    retry = state.get("retry_count", 0) + 1
    logs  = state.get("logs", [])
    logs.append(f"🔁 Retry #{retry}")

    # stop condition
    if retry >= MAX_RETRIES:
        logs.append("❌ Max retries hit – aborting.")
        return {
            **state,
            "retry_count": retry,
            "abort": True,            # <-- crucial for router
            "validation_passed": False,
            "logs": logs,
        }

    return {**state, "retry_count": retry, "logs": logs}
