
import re

def chunk_plsql_code(plsql_code: str, max_lines: int = 100) -> list:
    """
    Splits PL/SQL code into chunks of approximately `max_lines` lines.
    Also respects the PL/SQL delimiter `/` which ends a block.
    """
    lines = plsql_code.strip().splitlines()
    chunks = []
    current_chunk = []
    line_count = 0

    for line in lines:
        current_chunk.append(line)
        line_count += 1

        # If line is "/" or we exceed max_lines, treat as a chunk boundary
        if line.strip() == "/" or line_count >= max_lines:
            # Only add non-empty chunks
            chunk_str = "\n".join(current_chunk).strip()
            if chunk_str:
                chunks.append(chunk_str)
            current_chunk = []
            line_count = 0

    # Add any remaining code as the last chunk
    if current_chunk:
        chunk_str = "\n".join(current_chunk).strip()
        if chunk_str:
            chunks.append(chunk_str)

    return chunks
