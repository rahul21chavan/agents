# backend/tasks/conversion_runner.py
import uuid, asyncio, tempfile, os, traceback
from graph.main_graph import build_graph
from langgraph.errors import GraphRecursionError

# ── very small in‑memory job store (swap for Redis in prod) ────────────
JOBS: dict[str, dict] = {}

# ───────────────────────────────────────────────────────────────────────
# public helpers
# ───────────────────────────────────────────────────────────────────────
def submit_job(state_in: dict) -> str:
    job_id = uuid.uuid4().hex
    JOBS[job_id] = {
        "status":   "queued",     # queued ▸ running ▸ finished|failed
        "step":     "waiting",
        "logs":     [],           # 👈 always present, even if empty
        "download": None,
        "success":  None,
        "error":    None,
    }
    asyncio.create_task(_run_job(job_id, state_in))
    return job_id


def get_job(job_id: str) -> dict | None:
    return JOBS.get(job_id)

# ───────────────────────────────────────────────────────────────────────
# background worker
# ───────────────────────────────────────────────────────────────────────
async def _run_job(job_id: str, state_in: dict):
    print(f"🔁 Launching job runner for job_id: {job_id}")
    job = JOBS[job_id]

    if job.get("run_lock"):
        print(f"🛑 run_lock triggered — skipping job: {job_id}")
        return
    job["run_lock"] = True

    graph = build_graph().with_config(recursion_limit=50)
    job["status"] = "running"

    try:
        # ✅ Only run the graph ONCE
        final = await graph.ainvoke(state_in)

        # Save output file
        fname = f"pyspark_{job_id}.py"
        path  = os.path.join(tempfile.gettempdir(), fname)
        with open(path, "w", encoding="utf‑8") as f:
            f.write(final.get("pyspark_code", ""))

        job.update(
            status   = "finished",
            step     = "done",
            success  = bool(final.get("validation_passed")),
            download = f"/agent/download/{fname}",
            logs     = final.get("logs", job["logs"]),
        )

    except GraphRecursionError:
        job.update(
            status="failed",
            step="error",
            error="Graph recursion limit hit – try smaller file or revise agents.",
        )
    except Exception as exc:
        short_tb = traceback.format_exc(limit=4).splitlines()[-1]
        job.update(
            status="failed",
            step="error",
            error=f"{exc.__class__.__name__}: {exc}",
            logs=job["logs"] + [short_tb],
        )
