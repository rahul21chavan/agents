
import uuid
import re

def chunk_plsql_code_v2(plsql_code: str):
    blocks = []
    buffer = []
    current_id = lambda: str(uuid.uuid4())

    # Regular expressions for different block types
    block_patterns = {
        "PROCEDURE": re.compile(r"\bCREATE\s+(OR\s+REPLACE\s+)?PROCEDURE\b", re.IGNORECASE),
        "FUNCTION": re.compile(r"\bCREATE\s+(OR\s+REPLACE\s+)?FUNCTION\b", re.IGNORECASE),
        "PACKAGE": re.compile(r"\bCREATE\s+(OR\s+REPLACE\s+)?PACKAGE\b", re.IGNORECASE),
        "ANONYMOUS_BLOCK": re.compile(r"\bBEGIN\b.*\bEND\b", re.IGNORECASE | re.DOTALL),
        "CONTROL_FLOW": re.compile(r"\b(IF|FOR|WHILE|LOOP|CASE)\b", re.IGNORECASE),
        "DECLARE": re.compile(r"^DECLARE\b", re.IGNORECASE),
        "DDL": re.compile(r"\b(CREATE|ALTER|DROP|TRUNCATE|COMMENT|RENAME)\b", re.IGNORECASE)
    }

    def classify_block(code):
        for block_type, pattern in block_patterns.items():
            if pattern.search(code):
                return block_type
        return "UNKNOWN"

    lines = plsql_code.splitlines()
    for line in lines:
        buffer.append(line)
        if line.strip().endswith(";") or re.match(r"\s*END\s*;\s*$", line, re.IGNORECASE):
            block = "\n".join(buffer).strip()
            if block:
                block_type = classify_block(block)
                blocks.append({
                    "id": current_id(),
                    "type": block_type,
                    "code": block
                })
                buffer = []

    # Final buffer flush
    if buffer:
        block = "\n".join(buffer).strip()
        if block:
            block_type = classify_block(block)
            blocks.append({
                "id": current_id(),
                "type": block_type,
                "code": block
            })

    return blocks

def save_chunks_to_csv(blocks, filename):
    import pandas as pd
    df = pd.DataFrame(blocks)
    df.to_csv(filename, index=False)
