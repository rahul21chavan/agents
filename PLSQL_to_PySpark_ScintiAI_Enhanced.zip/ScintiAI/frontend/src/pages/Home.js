// src/pages/Home.js
import React, { useEffect, useState } from "react";
import { Box, Card, CardContent, Typography, Stack, CircularProgress } from "@mui/material";
import { motion } from "framer-motion";
import axiosInstance from "../api/axiosInstance";

export default function Home() {
  const [userEmail, setUserEmail] = useState("");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchUser = async () => {
      try {
        const res = await axiosInstance.get("/auth/me");  // <-- New endpoint we'll handle
        setUserEmail(res.data.email);
      } catch (err) {
        console.error("Failed to fetch user");
      } finally {
        setLoading(false);
      }
    };
    fetchUser();
  }, []);

  return (
    <Box maxWidth={800} mx="auto" mt={6} textAlign="center">
      <motion.div
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ duration: 0.5 }}
      >
        <Typography variant="h3" mb={3}>
          Welcome to ScintiAI
        </Typography>
      </motion.div>

      <motion.div
        initial={{ y: 20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ delay: 0.3 }}
      >
        {loading ? (
          <CircularProgress />
        ) : (
          <Typography variant="h5" mb={4}>
            {userEmail ? `Hello, ${userEmail}` : "Welcome!"}
          </Typography>
        )}
      </motion.div>

      <Card component={motion.div} initial={{ y: 20, opacity: 0 }} animate={{ y: 0, opacity: 1 }} transition={{ delay: 0.6 }}>
        <CardContent>
          <Stack spacing={2}>
            <Typography variant="h6">2 Easy Steps to Get Started:</Typography>
            <Typography>1️⃣ Configure your LLM Credentials</Typography>
            <Typography>2️⃣ Upload your SAS script for conversion</Typography>
          </Stack>
        </CardContent>
      </Card>
    </Box>
  );
}
