
import streamlit as st
import requests

st.set_page_config(page_title="PL/SQL ➝ PySpark Converter", layout="wide")

st.title("🚀 PL/SQL to PySpark Agentic Converter")
st.markdown("This app uses an agentic architecture to chunk, convert, validate, and merge your PL/SQL code into PySpark.")

uploaded_file = st.file_uploader("📂 Upload your PL/SQL file", type=["sql", "txt"])

if uploaded_file:
    plsql_code = uploaded_file.read().decode("utf-8")
    st.subheader("📄 Uploaded Code")
    st.code(plsql_code, language="sql")

    if st.button("Convert to PySpark"):
        with st.spinner("Calling backend agents..."):
            response = requests.post("http://localhost:8000/convert", json={"plsql_code": plsql_code})

        if response.status_code == 200:
            result = response.json()
            st.subheader("🧩 PL/SQL Chunks")
            for i, chunk in enumerate(result.get("chunks", [])):
                with st.expander(f"Chunk {i+1}"):
                    st.code(chunk, language="sql")

            st.subheader("🔥 PySpark Output")
            st.code(result.get("final_pyspark_code", ""), language="python")

            st.download_button("⬇️ Download PySpark", result.get("final_pyspark_code", ""), file_name="converted_pyspark.py")
        else:
            st.error("Conversion failed. Backend error.")
else:
    st.info("Upload a .sql or .txt file to begin.")
