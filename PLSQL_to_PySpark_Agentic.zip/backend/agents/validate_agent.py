
def validate_agent(pyspark_code: str) -> bool:
    return "print(" in pyspark_code  # crude check for demonstration
