
import streamlit as st
from backend.agents.parse_agent import chunk_plsql_code_v2
from backend.agents.llm_rule_agent import convert_block_to_pyspark
from dotenv import load_dotenv
import os

load_dotenv()
st.set_page_config(page_title="PL/SQL to PySpark Converter", layout="wide")

st.title("🔄 PL/SQL to PySpark Code Converter")
st.markdown("Upload your `.sql` file. The tool will chunk the PL/SQL code into logical blocks and convert each to PySpark using LLMs.")

uploaded_file = st.file_uploader("Upload PL/SQL file", type=["sql", "txt"])

if uploaded_file:
    plsql_code = uploaded_file.read().decode("utf-8")
    blocks = chunk_plsql_code_v2(plsql_code)
    
    st.subheader(f"🔍 Detected {len(blocks)} Logical Blocks")

    for block in blocks:
        with st.expander(f"Block Type: {block['type']} | ID: {block['id'][:8']}"):
            st.code(block['code'], language="sql")
            with st.spinner("Converting to PySpark..."):
                pyspark_code = convert_block_to_pyspark(block['code'])
                st.code(pyspark_code, language="python")
