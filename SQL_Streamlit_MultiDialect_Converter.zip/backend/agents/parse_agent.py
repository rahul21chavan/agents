
import re

def chunk_plsql_code_v2(code):
    chunks = []
    pattern = r"(?i)(CREATE(?:\s+(?:OR\s+REPLACE))?\s+(?:PROCEDURE|FUNCTION|PACKAGE|TRIGGER)[\s\S]+?END[\s\S]+?;)"
    matches = re.finditer(pattern, code, re.MULTILINE)
    for i, match in enumerate(matches):
        chunks.append({
            "id": f"plsql_block_{i}",
            "type": "PLSQL_BLOCK",
            "code": match.group(0).strip()
        })
    if not chunks:
        chunks.append({
            "id": "plsql_full",
            "type": "PLSQL_FULL",
            "code": code
        })
    return chunks

def chunk_tsql_code(code):
    statements = [stmt.strip() + ";" for stmt in code.split(";") if stmt.strip()]
    return [{"id": f"tsql_stmt_{i}", "type": "TSQL_STMT", "code": stmt} for i, stmt in enumerate(statements)]

def chunk_oracle_sql(code):
    pattern = r"(BEGIN[\s\S]+?END;)"
    matches = re.finditer(pattern, code, re.MULTILINE | re.IGNORECASE)
    chunks = [{"id": f"oracle_block_{i}", "type": "ORACLE_BLOCK", "code": m.group(0)} for i, m in enumerate(matches)]
    if not chunks:
        chunks.append({"id": "oracle_full", "type": "ORACLE_FULL", "code": code})
    return chunks

def chunk_code_by_dialect(dialect, code):
    if dialect == "pl/sql":
        return chunk_plsql_code_v2(code)
    elif dialect == "t-sql":
        return chunk_tsql_code(code)
    elif dialect == "oracle sql":
        return chunk_oracle_sql(code)
    else:
        return [{"id": "default", "type": "RAW", "code": code}]
