
from langchain.llms import OpenAI
from langchain.prompts import PromptTemplate
from langchain.chains import LLMChain

def convert_block_to_pyspark(block_code: str, dialect: str = "pl/sql") -> str:
    if dialect == "pl/sql":
        template = """You are a code assistant.
Convert this PL/SQL code block into PySpark DataFrame API or SQL.
Only output PySpark code.

PL/SQL:
{code}
"""
    elif dialect == "t-sql":
        template = """Convert the following T-SQL script to PySpark.
Only output valid PySpark code.

T-SQL:
{code}
"""
    elif dialect == "oracle sql":
        template = """Convert the following Oracle SQL block into PySpark equivalent.
Only output valid PySpark code.

Oracle SQL:
{code}
"""
    else:
        return "# Unsupported dialect"

    prompt = PromptTemplate.from_template(template)
    llm = OpenAI(temperature=0)
    chain = LLMChain(llm=llm, prompt=prompt)
    return chain.run(code=block_code)
