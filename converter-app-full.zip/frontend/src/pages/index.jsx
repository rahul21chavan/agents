
import React, { useState } from 'react';

export default function Home() {
  const [file, setFile] = useState(null);
  const [dialect, setDialect] = useState("plsql");
  const [output, setOutput] = useState("");

  const handleConvert = async () => {
    const form = new FormData();
    form.append("file", file);
    form.append("dialect", dialect);
    const res = await fetch("http://localhost:8000/convert", {
      method: "POST",
      body: form,
    });
    const data = await res.json();
    setOutput(data.converted_code);
  };

  return (
    <div className="p-8">
      <h1 className="text-2xl mb-4">SQL to PySpark Converter</h1>
      <select className="mb-4" onChange={(e) => setDialect(e.target.value)}>
        <option value="plsql">PL/SQL</option>
        <option value="tsql">T-SQL</option>
      </select>
      <input type="file" onChange={(e) => setFile(e.target.files[0])} className="mb-4" />
      <button onClick={handleConvert} className="bg-blue-500 text-white px-4 py-2 rounded">Convert</button>
      <pre className="mt-4 bg-gray-100 p-4">{output}</pre>
    </div>
  );
}
