
def dummy_chunker(code):
    return [code]
