
from langchain.llms import OpenAI
from langchain.prompts import PromptTemplate
from langchain.chains import LLMChain

def convert_code(source_code: str, dialect: str) -> str:
    if dialect.lower() == "plsql":
        template = """You are a migration assistant.
Convert this PL/SQL code into PySpark DataFrame API or SQL.
Only output PySpark code.

PL/SQL:
{code}
"""
    elif dialect.lower() == "tsql":
        template = """Convert this T-SQL script to PySpark.
Only output PySpark.

T-SQL:
{code}
"""
    else:
        template = "Unsupported dialect: {code}"

    prompt = PromptTemplate.from_template(template)
    llm = OpenAI(temperature=0)
    chain = LLMChain(llm=llm, prompt=prompt)
    return chain.run(code=source_code)
