import os
import streamlit as st
from dotenv import load_dotenv
import uuid

# Load environment variables
load_dotenv()
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY")

st.set_page_config(page_title="PL/SQL to PySpark Converter", layout="wide")
st.title("🌀 PL/SQL to PySpark Converter")

# Upload SQL file
uploaded_file = st.file_uploader("Upload your PL/SQL file", type=["sql"])

if uploaded_file:
    sql_code = uploaded_file.read().decode("utf-8")
    st.subheader("📜 Uploaded PL/SQL Code")
    st.code(sql_code, language="sql")

    # Simulate parsing into chunks
    st.subheader("🔍 Parsed SQL Blocks")
    blocks = [b.strip() for b in sql_code.split(";") if b.strip()]
    for i, block in enumerate(blocks, 1):
        st.markdown(f"**Block {i}:**")
        st.code(block + ";", language="sql")

    # Simulate Gemini-based conversion
    st.subheader("⚙️ Converted PySpark Code")
    converted_blocks = []
    for i, block in enumerate(blocks, 1):
        converted = f"# Converted block {i}\n# Original: {block[:40]}...\ndf_{i} = spark.sql("""{block}""")"
        converted_blocks.append(converted)
        st.code(converted, language="python")

    # Download button
    all_code = "\n\n".join(converted_blocks)
    file_name = f"converted_{uuid.uuid4().hex[:8]}.py"
    st.download_button("📥 Download PySpark Code", all_code, file_name=file_name, mime="text/x-python")
