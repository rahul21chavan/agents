# backend/graph/main_graph.py
from typing import TypedDict, List, Optional, Literal
from langgraph.graph import StateGraph, END

# ── node imports ───────────────────────────────────────────────
from agents.parse_agent      import parse_node
from agents.llm_rule_agent   import llm_rule_node   # primary converter
# from agents.llm_agent        import llm_node        # optional optimiser
from agents.validate_agent   import validate_node
from agents.feedback_agent   import feedback_node

# ── shared state ───────────────────────────────────────────────
class GraphState(TypedDict):
    sas_code: str
    # produced by parse & converter
    ast_blocks:     Optional[list]
    pyspark_chunks: Optional[list]
    pyspark_code:   Optional[str]

    # control / feedback
    failed_chunks:      Optional[list]
    validation_passed:  Optional[bool]
    retry_count:        Optional[int]
    abort:              Optional[bool]
    skip_llm:        bool

    # LLM credentials
    llm_provider: str
    llm_cred:    dict

    # misc
    rule_csv: Optional[str]
    logs:     List[str]

# ── router helpers ─────────────────────────────────────────────
def route_after_parse(st: GraphState) -> Literal["llm_rule", "feedback"]:
    return "llm_rule" if st.get("ast_blocks") else "feedback"
# def route_after_parse(st: GraphState) -> Literal["llm_rule", "validate", "feedback"]:
#     """
#     • normal flow        → llm_rule
#     • if skip_llm flag   → validate (rule step is skipped)
#     • if parse failed    → feedback
#     """
#     if not st.get("ast_blocks"):
#         return "feedback"
#     return "validate" if st.get("skip_llm") else "llm_rule"

def route_after_llm_rule(st: GraphState) -> Literal["validate", "feedback"]:
    # If converter left any failed IDs → go to feedback
    return "feedback" if st.get("failed_chunks") else "validate"

def route_after_validation(st: GraphState) -> Literal["end", "feedback"]:
    return "end" if st.get("validation_passed") else "feedback"

def route_from_feedback(st: GraphState) -> Literal["end", "parse"]:
    # Stop if abort flag set, else loop back to parse
    return "end" if st.get("abort") else "parse"

# ── build graph ────────────────────────────────────────────────
def build_graph() -> StateGraph:
    g = StateGraph(GraphState)

    # 1️⃣ register nodes
    g.add_node("parse",     parse_node)
    g.add_node("llm_rule",  llm_rule_node)
    g.add_node("validate",  validate_node)
    g.add_node("feedback",  feedback_node)
    # g.add_node("llm_opt", llm_node)

    # 2️⃣ entry
    g.set_entry_point("parse")

    # 3️⃣ edges ---------------------------------------------------------
    g.add_conditional_edges(
        "parse",
        route_after_parse,
        {
            "llm_rule": "llm_rule",
            "feedback": "feedback",
        },
    )

    g.add_conditional_edges(
        "llm_rule",
        route_after_llm_rule,
        {
            "validate": "validate",
            "feedback": "feedback",
        },
    )

    g.add_conditional_edges(
        "validate",
        route_after_validation,
        {
            "end": END,          # sentinel, not string!
            "feedback": "feedback",
        },
    )

    g.add_conditional_edges(
        "feedback",
        route_from_feedback,
        {
            "end": END,          # sentinel, not string!
            "parse": "parse",
        },
    )

    return g.compile()
