from typing import List, Dict
import re
import pandas as pd

def remove_comments(code: str) -> str:
    """Remove inline and block comments from SAS code."""
    code = re.sub(r"/\*.*?\*/", "", code, flags=re.DOTALL)  # Block comments
    code = re.sub(r"^\s*\*.*?;", "", code, flags=re.MULTILINE)  # Line comments
    return code

def extract_macro_blocks(code: str) -> List[Dict]:
    """Extract top-level macro blocks with start/end positions."""
    macro_pattern = re.compile(r"(%macro\b.*?%mend\s*;)", re.IGNORECASE | re.DOTALL)
    blocks = []
    for match in macro_pattern.finditer(code):
        blocks.append({
            "type": "macro",
            "start": match.start(),
            "end": match.end(),
            "code": match.group(1)
        })
    return blocks

def find_conditional_blocks(lines: List[str]) -> List[Dict]:
    """Identify %if %then %do ... %end blocks."""
    blocks = []
    stack = []
    start_idx = None

    for i, line in enumerate(lines):
        if re.match(r"^\s*%if\b.*?%then\s+%do\b", line, re.IGNORECASE):
            stack.append("start")
            if start_idx is None:
                start_idx = i
        elif re.match(r"^\s*%do\b", line, re.IGNORECASE) and not stack:
            stack.append("do_only")
            if start_idx is None:
                start_idx = i
        elif re.match(r"^\s*%end\s*;", line, re.IGNORECASE) and stack:
            stack.pop()
            if not stack:
                end_idx = i
                blocks.append({"start": start_idx, "end": end_idx})
                start_idx = None

    return blocks

def chunk_non_macro_block(code: str) -> List[Dict]:
    """Chunk the non-macro code into logical units."""
    lines = code.splitlines()
    cond_blocks = find_conditional_blocks(lines)
    cond_ranges = {(b["start"], b["end"]) for b in cond_blocks}
    used_indices = set()
    chunks = []

    # Group conditional blocks
    for start, end in cond_ranges:
        chunk_lines = lines[start:end + 1]
        chunks.append({"type": "conditional", "code": "\n".join(chunk_lines).strip()})
        used_indices.update(range(start, end + 1))

    # Handle remaining lines
    current_chunk = []
    current_type = "unknown"
    block_start_re = re.compile(r"^\s*(data|proc|%let|options)\b", re.IGNORECASE)

    for i, line in enumerate(lines):
        if i in used_indices:
            continue
        if block_start_re.match(line) and current_chunk:
            chunks.append({"type": current_type, "code": "\n".join(current_chunk).strip()})
            current_chunk = []
        if not current_chunk:
            kind_match = block_start_re.match(line)
            current_type = kind_match.group(1).lower() if kind_match else "unknown"
        current_chunk.append(line)

    if current_chunk:
        chunks.append({"type": current_type, "code": "\n".join(current_chunk).strip()})

    return chunks

def chunk_large_macros(macro_code: str) -> List[Dict]:
    """Break large macro block into sub-chunks if necessary."""
    lines = macro_code.splitlines()
    if len(lines) <= 500:
        return [{"type": "macro", "code": macro_code.strip()}]
    sub_chunks = []
    current_chunk = []
    block_start_re = re.compile(r"^\s*(data|proc|%let|options)\b", re.IGNORECASE)
    for line in lines:
        if block_start_re.match(line) and current_chunk:
            sub_chunks.append({"type": "macro-sub", "code": "\n".join(current_chunk).strip()})
            current_chunk = []
        current_chunk.append(line)
    if current_chunk:
        sub_chunks.append({"type": "macro-sub", "code": "\n".join(current_chunk).strip()})
    return sub_chunks

def split_code_excluding_macros(code: str, macro_blocks: List[Dict]) -> List[Dict]:
    """Split SAS code into non-macro and macro chunks in order."""
    all_blocks = []
    last_end = 0
    for mb in macro_blocks:
        if last_end < mb["start"]:
            pre_code = code[last_end:mb["start"]].strip()
            if pre_code:
                all_blocks.extend(chunk_non_macro_block(pre_code))
        all_blocks.append({"type": "macro", "code": mb["code"]})
        last_end = mb["end"]
    if last_end < len(code):
        post_code = code[last_end:].strip()
        if post_code:
            all_blocks.extend(chunk_non_macro_block(post_code))
    return all_blocks

def chunk_sas_code_v3(sas_code: str) -> List[Dict]:
    """
    Main chunker: returns list of {'id','type','code'} in exact order.
    IDs are sequential CHUNK_1, CHUNK_2, …
    """
    cleaned = remove_comments(sas_code)
    macros = extract_macro_blocks(cleaned)
    raw = []
    for blk in split_code_excluding_macros(cleaned, macros):
        if blk["type"] == "macro":
            line_count = blk["code"].count("\n")
            if line_count <= 500:
                raw.append(blk)
            else:
                raw.extend(chunk_large_macros(blk["code"]))
        else:
            raw.append(blk)

    # Assign simple sequential IDs
    final = []
    for idx, blk in enumerate(raw, start=1):
        final.append({
            "id": f"CHUNK_{idx}",
            "type": blk["type"],
            "code": blk["code"]
        })
    return final

def save_chunks_to_csv(chunks: List[Dict], path: str):
    df = pd.DataFrame(chunks)
    df.to_csv(path, index=False)

