import streamlit as st

def inject_styles():
    st.markdown("""
    <style>
    .stButton>button {
        color: #fff !important;
        background: linear-gradient(90deg, #FFD700 0%, #FFA500 100%) !important;
        border: none;
        border-radius: 6px;
        font-weight: 600;
        padding: 0.55em 1.2em !important;
        box-shadow: 0 2px 12px #FFD70044;
        margin-bottom: 4px;
    }
    .stTextArea textarea, .stTextInput input, .stFileUploader label {
        background: #f5f3d9 !important;
        color: #29335c !important;
        border-radius: 10px !important;
        border: 1.5px solid #FFD70033 !important;
        font-family: 'Fira Mono', monospace !important;
    }
    .stCode {
        background: #1f4068 !important;
        color: #FFD700 !important;
        border-radius: 12px !important;
        border: 1px solid #FFD70033 !important;
    }
    </style>
    """, unsafe_allow_html=True)