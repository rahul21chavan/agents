import streamlit as st
import pandas as pd
import requests
import json
from styles import inject_styles

BACKEND_URL = "http://localhost:8000"

inject_styles()

st.title("🔄 PL/SQL to PySpark Converter (Luxury UI)")

with st.sidebar:
    st.markdown("## LLM Credentials")
    provider = st.selectbox("Provider", ["Gemini", "Azure OpenAI"])
    creds = {"provider": provider}
    if provider == "Gemini":
        creds["GEMINI_API_KEY"] = st.text_input("Gemini API Key", type="password")
    else:
        creds["OPENAI_API_KEY"] = st.text_input("OpenAI API Key", type="password")
        creds["OPENAI_API_BASE"] = st.text_input("API Base URL")
        creds["OPENAI_API_TYPE"] = st.text_input("API Type", value="azure")
        creds["OPENAI_API_VERSION"] = st.text_input("API Version", value="2023-05-15")
        creds["DEPLOYMENT_NAME"] = st.text_input("Deployment Name")

    st.markdown("---")
    st.markdown("### Feedback")
    fb_text = st.text_area("Your feedback on the conversion", height=80)
    submit_fb = st.button("Submit Feedback")

code_input = st.text_area("PL/SQL Code", height=280)
if st.button("Chunk & Convert"):
    with st.spinner("Splitting code into blocks..."):
        resp = requests.post(
            f"{BACKEND_URL}/chunk/",
            data={"code": code_input, "max_chunk_size": 1200}
        )
        blocks = resp.json()["blocks"]
    blocks_df = pd.DataFrame({"PL/SQL Block": blocks})
    st.dataframe(blocks_df)
    converted_blocks = []
    for i, block in enumerate(blocks):
        with st.spinner(f"Converting block {i+1}..."):
            conv_resp = requests.post(
                f"{BACKEND_URL}/convert/",
                data={
                    "block": block,
                    "creds_json": json.dumps(creds),
                    "optimized": "false"
                }
            )
            converted_blocks.append(conv_resp.json()["output"])
    st.markdown("### Preview: Mapping")
    preview_df = pd.DataFrame({
        "PL/SQL Block": blocks,
        "Converted PySpark": converted_blocks
    })
    st.dataframe(preview_df)
    st.download_button("Download CSV", preview_df.to_csv(index=False), file_name="mapping.csv")

    if st.button("Generate Final Optimized PySpark Code"):
        final_resp = requests.post(
            f"{BACKEND_URL}/convert/",
            data={
                "block": code_input,
                "creds_json": json.dumps(creds),
                "optimized": "true"
            }
        )
        final_code = final_resp.json()["output"]
        st.code(final_code, language="python")
        st.download_button("Download Final PySpark", final_code, file_name="final_pyspark.py")

# Feedback submission
if submit_fb:
    requests.post(
        f"{BACKEND_URL}/feedback/",
        json={
            "user": "user1",
            "input": code_input,
            "output": "",  # Optionally include the converted output
            "feedback": fb_text,
            "timestamp": pd.Timestamp.now().isoformat()
        }
    )
    st.success("Feedback submitted. Thank you!")

# Validation agent
if st.button("Validate Final PySpark Code"):
    final_code = st.session_state.get("final_code", "")
    val_resp = requests.post(
        f"{BACKEND_URL}/validate/",
        json={"pyspark_code": final_code}
    )
    val_data = val_resp.json()
    if val_data["valid"]:
        st.success("The PySpark code looks valid!")
    else:
        st.error("Validation errors: " + ", ".join(val_data["errors"]))