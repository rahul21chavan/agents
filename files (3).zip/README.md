# PL/SQL to PySpark Converter (Luxury UI)

## Structure

- `backend/`: FastAPI backend for parsing, LLM conversion, feedback, and validation.
- `frontend/`: Streamlit frontend.

## Running

### Backend

```bash
cd backend
pip install -r requirements.txt
uvicorn main:app --reload
```

### Frontend

```bash
cd frontend
pip install -r requirements.txt
streamlit run app.py
```

## Features

- Parse PL/SQL into logical blocks with enhanced chunker.
- Convert each block or the entire script to PySpark using Gemini or Azure OpenAI.
- Collect user feedback and validate generated PySpark code.
- Download mapping and final output.

## Feedback & Validation

- Submit feedback using the sidebar.
- Validate PySpark code before download.

---