from fastapi import FastAPI, UploadFile, File, Form
from fastapi.middleware.cors import CORSMiddleware
from chunker import split_plsql_into_blocks
from llm_providers import get_llm_provider
from feedback_agent import router as feedback_router
from validation_agent import router as validation_router

import io

app = FastAPI()

# Enable CORS for frontend
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"], allow_credentials=True, allow_methods=["*"], allow_headers=["*"]
)

app.include_router(feedback_router)
app.include_router(validation_router)

@app.post("/chunk/")
async def chunk_plsql(code: str = Form(...), max_chunk_size: int = Form(1200)):
    blocks = split_plsql_into_blocks(code, max_chunk_size)
    return {"blocks": blocks}

@app.post("/convert/")
async def convert_block(
    block: str = Form(...),
    creds_json: str = Form(...),
    optimized: bool = Form(False)
):
    import json
    creds = json.loads(creds_json)
    provider = get_llm_provider(creds)
    if not provider:
        return {"error": "No provider configured"}
    if optimized:
        result = provider.convert_optimized(block)
    else:
        result = provider.convert(block)
    return {"output": result}