import json
from fastapi import APIRouter, Request

router = APIRouter()

feedback_store = []

@router.post("/feedback/")
async def collect_feedback(request: Request):
    data = await request.json()
    feedback = {
        "user": data.get("user"),
        "input": data.get("input"),
        "output": data.get("output"),
        "feedback": data.get("feedback"),
        "timestamp": data.get("timestamp"),
    }
    feedback_store.append(feedback)
    # Optionally, persist to disk or DB
    return {"status": "success", "msg": "Feedback recorded."}