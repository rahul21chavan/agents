from typing import Optional

class LLMProvider:
    def convert(self, block: str) -> str:
        raise NotImplementedError
    def convert_optimized(self, script: str) -> str:
        raise NotImplementedError

class GeminiProvider(LLMProvider):
    def __init__(self, api_key: str):
        import google.generativeai as genai
        genai.configure(api_key=api_key)
        self.model = genai.GenerativeModel("gemini-1.5-pro")
    def convert(self, block: str) -> str:
        prompt = (
            "You are a senior data engineer experienced in migrating legacy PL/SQL code to PySpark.\n\n"
            "Convert the following PL/SQL block into PySpark using the DataFrame API.\n"
            "Return only executable Python code.\n\n"
            f"PL/SQL Block:\n{block}\n"
        )
        try:
            resp = self.model.generate_content(prompt)
            return resp.text.strip()
        except Exception as e:
            return f"# Gemini Error: {e}"
    def convert_optimized(self, script: str) -> str:
        prompt = (
            "You are a senior data engineer experienced in migrating legacy PL/SQL code to PySpark.\n\n"
            "Convert the following ENTIRE PL/SQL script into a single, clean, production-ready PySpark script using the DataFrame API.\n"
            "Integrate all logic, deduplicate where possible, use idiomatic PySpark, and output only the final, unified, executable Python code. Do not simply concatenate per-block code: merge and optimize for clarity and maintainability.\n\n"
            f"Full PL/SQL Script:\n{script}\n"
        )
        try:
            resp = self.model.generate_content(prompt)
            return resp.text.strip()
        except Exception as e:
            return f"# Gemini Error: {e}"

class OpenAIProvider(LLMProvider):
    def __init__(self, creds):
        import openai
        self.openai = openai
        openai.api_key = creds["OPENAI_API_KEY"]
        openai.api_base = creds["OPENAI_API_BASE"]
        openai.api_type = creds["OPENAI_API_TYPE"]
        openai.api_version = creds["OPENAI_API_VERSION"]
        self.deployment_name = creds["DEPLOYMENT_NAME"]
    def convert(self, block: str) -> str:
        prompt = (
            "You are a data engineer. Convert the following PL/SQL code block into PySpark DataFrame API code.\n"
            "Only return valid, executable Python code. Do not include explanations, comments, or markdown.\n"
            f"PL/SQL Block:\n{block}\n"
        )
        try:
            resp = self.openai.ChatCompletion.create(
                engine=self.deployment_name,
                messages=[{"role": "user", "content": prompt}],
                temperature=0.3
            )
            return resp.choices[0].message.content.strip()
        except Exception as e:
            return f"# OpenAI Error: {e}"
    def convert_optimized(self, script: str) -> str:
        prompt = (
            "You are a data engineer. Convert the following ENTIRE PL/SQL script into a single, clean, production-ready PySpark script using the DataFrame API.\n"
            "Integrate all logic, deduplicate where possible, use idiomatic and maintainable PySpark, and output only the final, unified, executable Python code. Do not simply concatenate per-block code: merge and optimize for clarity and maintainability.\n\n"
            f"Full PL/SQL Script:\n{script}\n"
        )
        try:
            resp = self.openai.ChatCompletion.create(
                engine=self.deployment_name,
                messages=[{"role": "user", "content": prompt}],
                temperature=0.3
            )
            return resp.choices[0].message.content.strip()
        except Exception as e:
            return f"# OpenAI Error: {e}"

def get_llm_provider(creds) -> Optional[LLMProvider]:
    if creds and creds.get("provider") == "Gemini" and creds.get("GEMINI_API_KEY"):
        return GeminiProvider(creds["GEMINI_API_KEY"])
    elif creds and creds.get("provider") == "Azure OpenAI" and creds.get("OPENAI_API_KEY"):
        return OpenAIProvider(creds)
    return None