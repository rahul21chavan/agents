import re
import sqlparse
from typing import List

def regex_chunk_blocks(plsql_code: str) -> List[str]:
    code = plsql_code.replace('\r\n', '\n').replace('\r', '\n')
    # Enhanced regex for better PL/SQL block detection
    block_re = re.compile(
        r'((?:(?:CREATE\s+(?:OR\s+REPLACE\s+)?(?:FUNCTION|PROCEDURE|PACKAGE|TRIGGER)[\s\S]*?END\s*;)|'
        r'(?:DECLARE[\s\S]*?END\s*;)|'
        r'(?:BEGIN[\s\S]*?END\s*;)|'
        r'(?:[^;]+;)))',
        re.IGNORECASE
    )
    block_matches = block_re.findall(code)
    blocks = []
    for block in block_matches:
        block = block.strip()
        if block and block != '/':
            blocks.append(block)
    return blocks

def ast_chunk_blocks(plsql_code: str, max_chunk_size=1200) -> List[str]:
    statements = sqlparse.parse(plsql_code)
    blocks = []
    for stmt in statements:
        stmt_str = str(stmt).strip()
        if not stmt_str:
            continue
        if len(stmt_str) > max_chunk_size:
            inner_blocks = re.split(r'(?i)(?=BEGIN)', stmt_str)
            for ib in inner_blocks:
                ib = ib.strip()
                if not ib:
                    continue
                if len(ib) > max_chunk_size:
                    # Split further by statement
                    sub_blocks = []
                    temp = []
                    temp_len = 0
                    for part in ib.split(';'):
                        if not part.strip():
                            continue
                        temp.append(part + ';')
                        temp_len += len(part) + 1
                        if temp_len > max_chunk_size:
                            sub_blocks.append('\n'.join(temp).strip())
                            temp = []
                            temp_len = 0
                    if temp:
                        sub_blocks.append('\n'.join(temp).strip())
                    blocks.extend(sub_blocks)
                else:
                    blocks.append(ib)
        else:
            blocks.append(stmt_str)
    final_blocks = []
    for b in blocks:
        if not b.strip():
            continue
        if all(l.strip().startswith('--') or not l.strip() for l in b.split('\n')):
            continue
        final_blocks.append(b)
    return final_blocks

def split_plsql_into_blocks(plsql_code: str, max_chunk_size=1200) -> List[str]:
    regex_blocks = regex_chunk_blocks(plsql_code)
    all_blocks = []
    for block in regex_blocks:
        if len(block) > max_chunk_size or block.upper().startswith(('CREATE', 'DECLARE', 'BEGIN')):
            ast_blocks = ast_chunk_blocks(block, max_chunk_size)
            all_blocks.extend(ast_blocks)
        else:
            all_blocks.append(block)
    # Combine small blocks for batching
    cleaned_blocks = []
    temp = []
    for b in all_blocks:
        if not b.strip():
            continue
        if len(b) < 180:
            temp.append(b)
            if sum(len(x) for x in temp) > 300:
                cleaned_blocks.append('\n'.join(temp))
                temp = []
        else:
            if temp:
                cleaned_blocks.append('\n'.join(temp))
                temp = []
            cleaned_blocks.append(b)
    if temp:
        cleaned_blocks.append('\n'.join(temp))
    # Final split for large blocks
    final_blocks = []
    for b in cleaned_blocks:
        if len(b) > max_chunk_size:
            stmts = [s+';' for s in b.split(';') if s.strip()]
            buff = []
            buff_len = 0
            for stmt in stmts:
                buff.append(stmt)
                buff_len += len(stmt)
                if buff_len > max_chunk_size:
                    final_blocks.append('\n'.join(buff))
                    buff = []
                    buff_len = 0
            if buff:
                final_blocks.append('\n'.join(buff))
        else:
            final_blocks.append(b)
    final_blocks = [b for b in final_blocks if b.strip() and not all(l.strip().startswith('--') or not l.strip() for l in b.split('\n'))]
    return final_blocks