Terminal 1:(Main drectory)
- python -m venv venv
- venv\Scripts\activate
- pip install -r requirements.txt
- cd backend
- uvicorn main:app --reload

Terminal 2:
- cd frontend
- npm install
- npm install @mui/material @emotion/react @emotion/styled framer-motion react-toastify
- npm install @mui/icons-material
- npm start

Visit localhost:3000