# backend/routers/agent_manager.py
from fastapi import APIRouter, UploadFile, Form, Depends, HTTPException
from fastapi.responses import StreamingResponse
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
import tempfile, os, json

from db import get_session
from models.llm_credential import LLMCredential
from dependencies.auth_dependencies import get_current_user
from tasks.conversion_runner import submit_job, get_job

router = APIRouter(tags=["Conversion"])

# ──────────────────────────────────────────────────────────────
# 1.  Kick‑off a conversion job
# ──────────────────────────────────────────────────────────────
@router.post("/convert")
async def start_conversion(
    file: UploadFile,
    llm_cred_id: int = Form(...),
    session: AsyncSession = Depends(get_session),
    current_user      = Depends(get_current_user),
):
    # Guard: only .sas allowed
    if not file.filename.lower().endswith(".sas"):
        raise HTTPException(400, "Only .sas files are supported.")

    sas_code = (await file.read()).decode("utf‑8", errors="ignore")

    # Fetch the chosen credential (and be sure it belongs to the user)
    stmt = select(LLMCredential).where(
        LLMCredential.id == llm_cred_id,
        LLMCredential.user_id == current_user.id,
    )
    cred: LLMCredential | None = (await session.execute(stmt)).scalar_one_or_none()
    if cred is None:
        raise HTTPException(404, "Credential not found")

    # Prepare exactly the fields the agents need
    cred_payload = {
        "openai_api_base":    cred.openai_api_base,
        "openai_api_key":     cred.openai_api_key,
        "openai_api_version": cred.openai_api_version,
        "deployment_name":    cred.deployment_name,
        "model_name":         cred.model_name,
        "google_api_key":     cred.google_api_key,
    }

    # Initial graph state – ALWAYS include an empty log list
    state_in = {
        "sas_code":      sas_code,
        "llm_provider":  cred.provider,
        "llm_cred":      cred_payload,
        "logs": [],                      # ← prevents KeyError in UI
    }

    job_id = submit_job(state_in)
    return {"job_id": job_id}


# ──────────────────────────────────────────────────────────────
# 2.  Poll job status (UI calls this every 2‑3 s)
# ──────────────────────────────────────────────────────────────
@router.get("/status/{job_id}")
async def poll_status(job_id: str):
    job = get_job(job_id)
    if job is None:
        raise HTTPException(404, "Job not found")
    # Always return a logs list, even if empty
    return {
        "status":  job.get("status", "unknown"),
        "logs":    job.get("logs", []),
        "success": job.get("success"),
        "download": job.get("download"),
        "error":   job.get("error"),
    }


# ──────────────────────────────────────────────────────────────
# 3.  Download generated PySpark script
# ──────────────────────────────────────────────────────────────
@router.get("/download/{fname}")
async def download_file(fname: str):
    path = os.path.join(tempfile.gettempdir(), fname)
    if not os.path.exists(path):
        raise HTTPException(404, "file expired")
    return StreamingResponse(
        open(path, "rb"),
        media_type="text/x-python",
        headers={"Content-Disposition": f'attachment; filename=\"{fname}\"'},
    )
